
public class Ejercicio4 {

	public static void main(String[] args) {
		double factorial = 1;
		double num = 15;
		while (num != 0) {
			  factorial=factorial*num;
			  num--;
			}
		System.out.println(factorial);
	}
}
