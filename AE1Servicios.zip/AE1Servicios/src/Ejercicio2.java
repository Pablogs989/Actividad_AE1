import java.util.ArrayList;
import java.util.List;

public class Ejercicio2 {

	public static void main(String[] args) {
		String[] nombres = new String[] {"Victor","Pablo","Jose","Adrian","Ruben","Edu"};
		for (int i = 0; i < nombres.length; i++) {
			System.out.println(nombres[i]);
			System.out.println("");
		}

		List <String> nombres2 = new ArrayList();
		nombres2.add("Victor"); nombres2.add("Pablo"); nombres2.add("Jose"); nombres2.add("Adrian"); nombres2.add("Ruben");nombres2.add("Edu");
		System.out.println(nombres2.toString());
	}

}
