import java.util.Scanner;

public class Ejercicio8 {

	public static boolean esPrimo(int numero) {
		  if (numero == 0 || numero == 1 || numero == 4) {
		    return false;
		  }
		  for (int x = 2; x < numero / 2; x++) {
		    if (numero % x == 0)
		      return false;
		  }
		  return true;
		}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Primer numero del intervalo: ");
		int num1 = scan.nextInt();
		System.out.println("Segundo numero del intervalo: ");
		int num2 = scan.nextInt();
		int num = num1;
		
		do {
			num = num + 1;
			if (esPrimo(num)) {
				System.out.println(num + ". Es primo");
			} else {
				System.out.println(num + ". No es primo");
			}
			
		} while (num != num2);
	}

}
