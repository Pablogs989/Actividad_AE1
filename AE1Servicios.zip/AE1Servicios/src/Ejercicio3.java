import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int total = 0;
		System.out.println("Numero: ");
		int num = scan.nextInt();
		for(int i = 1; i < num; i++) {
			if(i%2 == 0) {
				total = total + i;
			}
		}
		System.out.println(total);
	}
}
