import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Nombre: ");
		String nombre = scan.nextLine();
		System.out.println("Años de experiencia: ");
		int años = scan.nextInt();
		
		if (años < 1) {
			System.out.println(nombre + ": Desarrollador Junior L1 - 15000-18000");
		} else if (años >= 1 && años <= 2) {
			System.out.println(nombre + ": Desarrollador Junior L2 – 18000-22000");

		} else if (años >= 3 && años <= 5) {
			System.out.println(nombre +": Desarrollador Senior L1 – 22000-28000");

		} else if (años > 5 && años <= 8) {
			System.out.println(nombre +": Desarrollador Senior L2 – 28000-36000");

		} else if (años > 8) {
			System.out.println(nombre +": Analista / Arquitecto. Salario a convenir en base a rol");

		}
	}

}


