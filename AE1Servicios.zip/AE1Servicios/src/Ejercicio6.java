import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) {
		int[] numeros = new int[5];
		Scanner scan = new Scanner(System.in);

		for (int i = 0; i < numeros.length; i++) {
			System.out.println("Numero: ");
			numeros[i] = scan.nextInt();
		}
		for(int i = numeros.length - 1; i >= 0; i--) {
			System.out.println(numeros[i]);
		}
		int suma = 0;
		for(int i = numeros.length - 1; i >= 0; i--) {
			suma += numeros[i];
		}
		System.out.println(suma);
	}
}
