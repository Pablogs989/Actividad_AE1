import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		sayHello();
	}
	
	public static void sayHello(){
		System.out.println("Hola mundo");

	}
}
