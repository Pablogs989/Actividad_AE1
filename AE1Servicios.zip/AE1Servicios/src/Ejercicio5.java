
public class Ejercicio5 {

	public static void main(String[] args) {
		int[] numeros = new int[] {1,2,3,4,5,6,72,12};
		int max = 0;
		for(int i = 0; i < numeros.length; i++) {
			if(numeros[i] > max) {
				max = numeros[i];
			}
		}
		System.out.println(max);
	}

}
