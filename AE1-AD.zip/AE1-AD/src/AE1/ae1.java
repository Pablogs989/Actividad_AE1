package AE1;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;


public class ae1 {

	public static String bytesGigas(long bytes, boolean si) {
		int unit = si ? 1000 : 1024;
		if (bytes < unit) return bytes + " B";
		int exp = (int) (Math.log(bytes) / Math.log(unit)); 
		String pre = (si ? "kMGTPE" : "KMGTPE").charAt(exp-1) + (si ? "" : "i");
		return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre); }
	
	public static void getInfo(File fichero) {
		System.out.println("Nombre del archivo:\t" + fichero.getName());
		if (fichero.isFile()) {
			System.out.println("Tipo: Fichero");
		} else if (fichero.isDirectory()) {
			System.out.println("Tipo: Directorio");
		}
		System.out.println("Ruta:\t" + fichero.getPath());
		
		long lastModified = fichero.lastModified();

		String pattern = "yyyy-MM-dd hh:mm aa";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		
		Date lastModifiedDate = new Date( lastModified );

		System.out.println( "El archivo " + fichero.getName() + " fue mododficado el " + simpleDateFormat.format( lastModifiedDate ) );
		System.out.println("Oculto:\t" + fichero.isHidden());
	
		
		if (fichero.isFile()) {
			System.out.println("Tamaño:\t" + fichero.length() + " bytes");

		}
		
		if (fichero.isDirectory()) {
			File[] lista = fichero.listFiles();    
			int cantidad=0;

			  for (int i = 0; i < lista.length; i++) 
			      if (lista[i].isFile())
			           cantidad++;
			  System.out.println("\n Hay " +  cantidad + " archivos");
			  System.out.println("Espacio libre: " + bytesGigas(fichero.getFreeSpace(), true));
			  System.out.println("Espacio total: " + bytesGigas(fichero.getTotalSpace(),true));
		}
	}
	
	public static void crearCarpeta(File fichero) {
	    Scanner scan = new Scanner(System.in);
		System.out.println("Nombre del nuevo directorio: ");
	    String nombre = scan.nextLine();
		File directorio = new File(fichero.getPath() + "/" + nombre);
        if (!directorio.exists()) {
            if (directorio.mkdirs()) {
                System.out.println("Directorio creado");
            } else {
                System.out.println("Error al crear directorio");
            }
        }
	}
	
	
	public static void crearFichero(File fichero) throws IOException {
	    Scanner scan = new Scanner(System.in);
		System.out.println("Nombre del nuevo fichero: ");
	    String nombre = scan.nextLine();
		File archivo = new File(fichero.getPath() + "/" + nombre);
		if (archivo.createNewFile())
		    System.out.println("El fichero se ha creado correctamente");
		  else
		    System.out.println("No ha podido ser creado el fichero");
	}
	
	public static void eliminar(File fichero) throws IOException {
	    Scanner scan = new Scanner(System.in);
		System.out.println("Nombre del archivo a eliminar: ");
	    String nombre = scan.nextLine();
		File archivo = new File(fichero.getPath() + "/" + nombre);
		 if (!archivo.exists()) {
			System.out.println("Este archivo no existe");
		 } else if (!archivo.isDirectory()) {
			archivo.delete();
			System.out.println("Fichero eliminado correctamente");
		} else {
			File[] lista = archivo.listFiles();
			for (int i = 0; i < lista.length; i++) {
				lista[i].delete();
			}
			archivo.delete();
			System.out.println("Directorio eliminado correctamente");
		}
	}
	
	public static void renombrar(File fichero) throws IOException {
		Scanner scan = new Scanner(System.in);
		System.out.println("Nombre del archivo a renombrar: ");
	    String nombre = scan.nextLine();
		File archivo = new File(fichero.getPath() + "/" + nombre);
		if (archivo.exists()) {
			System.out.println("Nuevo nombre: ");
		    String nuevoNombre = scan.nextLine();
			File nuevo = new File(fichero.getPath() + "/" + nuevoNombre);
			archivo.renameTo(nuevo);
            System.out.println("Archivo renombrado");
		} else System.out.println("Este aerchivo no existe");

	}
	
	
	public static void main(String[] args) throws IOException {
		
		String dir = args[0];
		File directorio = new File(dir);
		
		System.out.println("1.RECIBIR INFORMACION");
		System.out.println("2.CREAR CARPETA");
		System.out.println("3.CREAR FICHERO");
		System.out.println("4.ELIMINAR CARPETA/FICHERO");
		System.out.println("5.RENOOMBRAR CARPETA/FICHERO");
		System.out.println("Escribe un numero entre 1..4");

	    Scanner scan = new Scanner(System.in);
	    String funcion = scan.nextLine();
	    
	    switch (Integer.parseInt(funcion)) {
		case 1: {
			getInfo(directorio);
			break;
		}
		case 2:{
			crearCarpeta(directorio);
			break;
		}
		case 3: {
			crearFichero(directorio);
			break;
		}
		case 4: {
			eliminar(directorio);
			break;
		}
		case 5: {
			renombrar(directorio);
			break;
		}
		default:
			System.out.println("Cebe ser un numero entre 1...4");
		}

	}
	
}